package exception;

import com.Carlson;
import com.Character;

public class flyExeption extends Exception {
    public flyExeption(Character c) {
        super(String.format("%s не может взлететь так как выключен пропелер", c.getName()));
    }

    @Override
    public String getMessage() {
        return super.getMessage();
    }
}
