package com;

public class Story {

}
