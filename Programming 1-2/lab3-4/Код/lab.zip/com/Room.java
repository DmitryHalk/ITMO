package com;

import java.util.ArrayList;

public class Room {
    protected double area;
    protected int doorCount;
    protected ArrayList<Window> windows;

    public Room(double area, int doorCount, ArrayList<Window> windows) {
        this.area = area;
        this.doorCount = doorCount;
        this.windows = windows;
    }

    public Room(double area, int doorCount) {
        this.area = area;
        this.doorCount = doorCount;
    }

    public Room(double area, ArrayList<Window> windows) {
        this.area = area;
        this.windows = windows;
    }


}
