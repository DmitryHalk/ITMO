package com;

import java.util.ArrayList;
import java.util.List;

public class Flat {
    private ArrayList<Room> rooms;
    private int area;

    // Конструктор без комнат
    public Flat(int area) {
        this.rooms = new ArrayList<>();
        this.area = area;
    }

    // Конструктор с начальными комнатами
    public Flat(int area, Room... initialRooms) {
        this.area = area;
        this.rooms = new ArrayList<>();
        for (Room room : initialRooms) {
            rooms.add(room);
        }
    }

    // Конструктор с существующим списком
    public Flat(List<Room> rooms, int area) {
        this.rooms = new ArrayList<>(rooms); // Создаем копию
        this.area = area;
    }

    public int getArea() {
        return area;
    }

    public void addRoom(Room room) {
        if (room != null) {
            rooms.add(room);
        }
    }
}
