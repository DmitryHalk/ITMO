package com;

import exception.eatException;

import java.util.Objects;

public abstract class Item {
    protected Character owner;
    protected String name;

    protected Item(String name, Character owner) {
        this.name = name;
        this.owner = owner;
    }

    public abstract void use() throws eatException;

    public Character getOwner() {
        return owner;
    }

    public String getName() {
        return name;
    }

    public void setOwner(Character owner) {
        this.owner = owner;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        Item item = (Item) o;
        return Objects.equals(owner, item.owner) && Objects.equals(name, item.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(owner, name);
    }

    @Override
    public String toString() {
        return "Item{" +
                "owner=" + owner +
                ", name='" + name + '\'' +
                '}';
    }
}
