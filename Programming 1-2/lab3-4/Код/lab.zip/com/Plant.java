package com;

public record Plant(String name, int height, Color color) {

}
