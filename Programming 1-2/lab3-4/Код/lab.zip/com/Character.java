package com;
import interfaces.Move;
import java.util.ArrayList;
import java.util.Objects;

public abstract class Character implements Move{
    protected String name;
    protected ArrayList<Item> hold;
    protected Mood mood;
    protected Room location;

    Character(String name, Mood mood, Room location){
        this.name = name;
        this.mood = mood;
        this.location = location;
    }

    Character(String name, Room location){
        this.name = name;
        this.mood = Mood.NEUTRAL;
        this.location = location;
    }

    public String getName() {
        return name;
    }

    public ArrayList<Item> getHold() {
        return hold;
    }

    public Mood getMood() {
        return mood;
    }

    public Room getLocation() {
        return location;
    }

    public void hear(SoundType s){

    }

    public void makeSounds(SoundType s){

    }

    public void eat(Food food){

    }

    public void take(Item item, Room location) {

    }

    public void give(Item item, Character pers){

    }

    public void put(Item item, Room location){

    }

    public void changeMood(Mood mood){
        this.mood = mood;
    }

    @Override
    public void walkTo(Room r){

    }

    @Override
    public void runTo(Room r){

    }

    @Override
    public void chase(Character c){

    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        Character character = (Character) o;
        return Objects.equals(name, character.name) && Objects.equals(hold, character.hold) && mood == character.mood && Objects.equals(location, character.location);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, hold, mood, location);
    }

    @Override
    public String toString() {
        return "Character{" +
                "name='" + name + '\'' +
                ", hold=" + hold +
                ", mood=" + mood +
                ", location=" + location +
                '}';
    }
}
