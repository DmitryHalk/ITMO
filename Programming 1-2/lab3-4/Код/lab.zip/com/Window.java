package com;

public class Window {
    private boolean isOpen;

    public void toggle(){
        if (isOpen){
            isOpen = false;
        } else {
            isOpen = true;
        }
    }
}
