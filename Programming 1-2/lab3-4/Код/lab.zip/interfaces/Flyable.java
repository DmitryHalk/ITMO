package interfaces;

import exception.flyExeption;

public interface Flyable {

    public void takeWing() throws flyExeption;
    public void up(double height) throws flyExeption;
    public void down(double height) throws flyExeption;

}
