package interfaces;

import com.Room;
import com.Character;

public interface Move {
    public void walkTo(Room room);
    public void runTo(Room room);
    public void chase(Character pers);
}
